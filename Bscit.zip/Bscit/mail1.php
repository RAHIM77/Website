 <?php
$to = $_POST["email"];
$subject = $_POST["subject"];
$txt = "Hello,".$_POST["name"]."\n\rwe are happy to hear you. \n\r We got your question regarding ".$_POST["subject"]."\n\r our experts will contact you soon. \n\r Thank You.";
$txt.="\n\r Your doubt is as follows :\n\r".$_POST["doubt"];
$headers = "From: Rahim" . "\r\n" . "CC: satyamjaiswal97@gmail.com";
$m=mail($to,$subject,$txt,$headers);
if($m==1){
echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Mail Sent Successfully, Thank You!!')
    window.location.href='http://localhost/bscit/index.html';
    </SCRIPT>");

}
?>